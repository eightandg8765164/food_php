<html>
	<head>
		<title>訂食吧-註冊會員</title>
	</head>
	<body>
		<center><b>
		<br>
		<br>
		<br>
			<img src="food_p\1.jpg"
			width="25%" height="25%"></image>
		<br>
		
			<font size="5" color=#A3A3FF>
			註冊帳號　 
			<img src="food_p\5.jpg"
			width="3%" height="5%"></image>
			<font size="5" color=#A3A3FF>
			　信箱認證　 
			<img src="food_p\5.jpg"
			width="3%" height="5%"></image>
			<font size="5" color=#FF5959>
			　 註冊成功　　
		<br>
		<br>
		<font size="5" color=#000000>
		3.註冊成功
		<br>
		<br>
		恭喜您！您已正式成為會員。

		
		</center>
	</body>
</html>