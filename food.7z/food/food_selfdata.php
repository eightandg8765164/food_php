<html>
	<head>
		<title>訂食吧-註冊會員</title>
	</head>
	<body>
		<center><b>
		<br>
		<br>
		<br>
			<img src="http://www.iconpng.com/png/universal-01/user58.png"
			width="15%" height="25%"></image>
		<br>
		
			<font size="5" color=#A3A3FF>
			　孟繁淳　 
			
		<br>
		<br>
		<font size="5" color=#000000>
		權限：會員
		<br>
		<br>
		電話：0910666525
		<br>
		<br>
		信箱：perer850609@gmail.com
		

		
		</center>
	</body>
</html>