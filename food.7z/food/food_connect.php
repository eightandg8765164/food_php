<html>
	<head>
		<title>訂食吧-登入</title>
	</head>
	<body>
		<?php session_start(); ?>
		<?php
		//連接資料庫
		//只要此頁面上有用到連接MySQL就要include它
		include("food_mysql_connect.inc.php");
		$id = $_POST['u_account'];
		$pw = $_POST['u_pwd'];

		//搜尋資料庫資料
		$sql = "SELECT * FROM user";
		$result = mysql_query($sql);
		$row = @mysql_fetch_row($result);

		//判斷帳號與密碼是否為空白
		//以及MySQL資料庫裡是否有這個會員
		if($id != null && $pw != null && $row[0] == $id && $row[1] == $pw)
		{
       		 //將帳號寫入session，方便驗證使用者身份
       		 $_SESSION['user_mail'] = $id;
      		  echo '登入成功!';
      		 
		}
		else
		{
       		 echo '登入失敗!';
       		
		}
		?>
	</body>
</html>